
package met100grades;

public class gradeBook{
    private String name;
    private double averageMarks;
    private int totalMarks;
    private int exam1, exam2, exam3;
    
    public gradeBook(String name, int exam1, int exam2, int exam3){
        this.name = name;
        this.exam1 = exam1;
        this.exam2 = exam2;
        this.exam3 = exam3;
    }
    
    public String name(){
        this.name = name;
        return this.name;
    }
    
    public gradeBook(double averageMarks, int totalMarks){
        this.totalMarks = totalMarks;
        this.averageMarks = averageMarks;
    }
    
    public int totalMarks(){
        return exam1 + exam2 + exam3;
    }
    
    public double averageMarks(){
        return exam1 + exam2 + exam3 / 3;
    }
    
    
    
}