/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package met100grades;

/**
 *
 * @author PAM
 */

public class MET100Grades {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        gradeBook sem = new gradeBook("Alice", 80, 78, 90);
        gradeBook rev = new gradeBook("Alicia", 80, 78, 90);
        gradeBook rem = new gradeBook("Alex", 60, 28, 90);
        
            System.out.println("Name: \t Score: \t Average: \t");
            System.out.printf(" %s \t %d \t %f \t", 
                    sem.name(), sem.totalMarks(), sem.averageMarks() );
            
            System.out.printf(" %s \t %d \t %f \t",
                    rev.name(), rev.totalMarks(), rev.averageMarks() );
            
            System.out.printf(" %s \t %d \t %f \t",
                    rem.name(), rem.totalMarks(), rem.averageMarks() );
            
    }
    
}
